// ─────────────────────────────────────────────────────────────────────────
// FIREBASE CONFIG TEMPLATE
//
// 1. Go to https://console.firebase.google.com → create/select a project.
// 2. Project settings → General → "Your apps" → Add app → Web (</>).
// 3. Copy the config object Firebase gives you and paste the values below.
// 4. Rename this file to `firebase-config.js` and place it at:
//       src/js/firebase-config.js
//    (src/js/firebase-init.js imports it from there.)
// 5. Enable the products you need:
//    - Authentication → Sign-in method → enable "Google" and "Email/Password"
//    - Firestore Database → Create database (production mode)
//    - Deploy firebase/firestore.rules with:
//        firebase deploy --only firestore:rules
// 6. For Android (Capacitor), also download google-services.json from
//    Project settings → Your apps → Android app (com.affilio.app) and place
//    it at android/app/google-services.json
// ─────────────────────────────────────────────────────────────────────────

export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Required for Google Sign-In on Android via Capacitor (Web client ID,
// NOT the Android client ID) — found in Google Cloud Console → Credentials,
// or Firebase → Authentication → Sign-in method → Google → Web SDK config.
export const googleWebClientId = "YOUR_WEB_CLIENT_ID.apps.googleusercontent.com";
